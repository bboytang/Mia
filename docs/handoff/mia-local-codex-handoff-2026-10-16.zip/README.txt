Mia Codex handoff snapshot
Repository: https://github.com/bboytang/Mia
Branch: feature/mia-persona-memory-v1.2
Patch base: 139bc0fa4e64ceeed173f36ac99229233bed559f

Preferred: pull the latest task branch and read docs/mia-local-codex-handoff.md.
The latest branch already contains this handoff and candidate code. DO NOT apply the patch again.

Alternative, only when working at the exact patch base: read HANDOFF.md, review tracked.patch, run git apply --check before applying, and copy untracked/ files to matching repository paths after comparing existing files. Never overwrite unrelated user work.

Recovery code is a candidate, not a verified release. Existing CI handles need fresh status checks.
No credentials, .git, dependencies or generated builds are included.
